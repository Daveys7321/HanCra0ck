return {
  q = module.load(header.id, 'spell/q'),
  w = module.load(header.id, 'spell/w'),
  e = module.load(header.id, 'spell/e'),
  r1 = module.load(header.id, 'spell/r1'),
  r2 = module.load(header.id, 'spell/r2'),
  flash = module.load(header.id, 'spell/flash'),
}