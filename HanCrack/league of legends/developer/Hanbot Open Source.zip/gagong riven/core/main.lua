return {
  ai = module.load(header.id, 'core/ai'),
  draw = module.load(header.id, 'core/draw'),
}